<template>
  <v-container>
    <v-alert type="info" :value="true">
      레벨 2 일반 가입자
    </v-alert>
  </v-container>
</template>
