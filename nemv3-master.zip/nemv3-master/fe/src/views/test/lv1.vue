<template>
  <v-container>
    <v-alert type="info" :value="true">
      레벨 1 중간관리자
    </v-alert>
  </v-container>
</template>
