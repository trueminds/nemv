<template>
  <v-container>
    <v-alert type="info" :value="true">
      레벨 0 관리자
    </v-alert>
  </v-container>
</template>
